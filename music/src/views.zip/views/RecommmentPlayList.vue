<template>
  <section>
    <div class="title">
      <BorderTitle><slot></slot></BorderTitle>
    </div>

      <ul class="playlist">
        <PlayListItem :currentRecommments="currentRecommments"></PlayListItem>
      </ul>

  </section>
</template>

<script>
import BorderTitle from "./BorderTitle";
import PlayListItem from "./PlayIistItem";
export default {
  components: {
    BorderTitle,
    PlayListItem,
  },
  props: ["currentRecommments"],
};
</script>

<style lang="scss">

</style>