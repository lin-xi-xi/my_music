<template>
  <div>
      <p>搜索</p>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>