<template>
  <div class="PlayFullLyric" @click="$emit('toggle-show-lyric')">
     ccc
  </div>
</template>

<script>
export default {

}
</script>

<style>
.PlayFullLyric{
    position: absolute;
    z-index: 300;
    width: 100vw;
    height: 100vh;
    top: 60px;
    display: flex;
    clear: both;
    background: red;

}
</style>