<template>
  <div class="bigPlayFooter">
    <div class="controls_list_play_list">
      <div class="play_list_box">
        <div class="play_list_box_inner">
          <ul v-for="(item, index) in playlist" :key="index">
            <li>ss</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="progress">
      <div class="progress_left">
        <span>{{ timer }}</span>
      </div>
      <div class="progress_center">
        <input
          type="range"
          min="0"
          :max="durationTime"
          step="1"
          :value="duration"
          @input="getValue"
        />
        <span
          :style="{ width: (currentTime / durationTime) * 100 + '%' }"
        ></span>
        <i
          ref="span"
          :style="{ left: (currentTime / durationTime) * 100 + '%' }"
        ></i>
      </div>
      <div class="progress_right">
        <span>{{ duration }}</span>
      </div>
    </div>
    <div class="controls">
      <div class="controls_random">
        <img src="../../assets/images/random.png" alt="" />
      </div>
      <div class="controls_pre">
        <img
          src="../../assets/images/pre.png"
          alt=""
          @click="$emit('clickpre')"
        />
      </div>
      <div class="controls_pause_play">
        <div class="controls_pause">
          <img
            src="../../assets/images/stop.png"
            alt=""
            v-if="state == '播放'"
            @click="$emit('clickPlay', '暂停')"
          />
          <img
            src="../../assets/images/bofan.png"
            alt=""
            v-if="state == '暂停'"
            @click="$emit('clickPause', '播放')"
          />
        </div>
      </div>
      <div class="controls_next">
        <img
          src="../../assets/images/next.png"
          alt=""
          @click="$emit('clicknext')"
        />
      </div>
      <div class="controls_list">
        <img src="../../assets/images/list.png" alt="" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: [
    "timer",
    "duration",
    "currentTime",
    "durationTime",
    "state",
    "playlist",
  ],
  //   data() {
  //       return {
  //           state:""
  //       }
  //   },
  methods: {
    getValue: function (e) {
      console.log(e.target.value);
      this.$emit("updateCurrentTime", e.target.value);
    },
  },
};
</script>

<style lang="scss">
@import url("../../assets/css/bigPlayFooter.css");
</style>