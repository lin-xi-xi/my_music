<template>
  <div class="songItem">
    <ul v-for="(item, index) in newSong" :key="index">
      <li class="song-item" @click="clickPaused(index, item.id)">
        <div>
          <h5>{{ newSong[index].name }}</h5>
          <p>
            <i :style="imgurl"></i>
            <span
              v-for="(artist, index2) in newSong[index].song.artists"
              :key="index2"
            >
              <template v-if="index2"> / </template>{{ artist.name }} </span
            ><span>- {{ newSong[index].name }}</span>
          </p>
        </div>
        <div class="icon">
          <span
            v-if="changePaused && newSong[index].id == changePaused.id"
            class="playing"
            :class="{ paused: changePaused && changePaused.paused == '暂停' }"
          >
            <i></i>
            <i></i>
            <i></i>
            <i></i>
          </span>
          <span :style="imgurl2" v-else></span>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["newSong", "paused", "currentMusic", "currentIndex"],

  methods: {
    clickPaused: function (index, id) {
      console.log(this.changePaused);

      this.changePaused = { paused: "播放", id: id };
      this.$emit("translate-music", [this.newSong, this.newSong[index], index]);
    },
  },
  watch: {
    currentIndex: function () {
      this.changePaused.id = this.newSong[this.currentIndex].id;
      this.$emit("translate-music", [
        this.newSong,
        this.newSong[this.currentIndex],this.currentIndex
      ]);
    },
    paused: function () {
      this.changePaused = this.paused;
    },
  },

  data() {
    return {
      id: "",
      changePaused: null,
      imgurl: {
        background:
          "url(" + require("../assets/images/index_icon.png") + ")no-repeat",
        backgroundSize: "166px 97px",
      },
      imgurl2: {
        background:
          "url(" +
          require("../assets/images/index_icon.png") +
          ")no-repeat -24px 0",
        backgroundSize: "166px 97px",
      },
    };
  },
};
</script>

<style lang="scss">
.songItem {
  ul {
    display: flex;
    li {
      width: 100%;
      height: 54px;
      padding: 6px 0px;
      margin-left: 10px;
      border-bottom: 1px solid #dcdada72;
      display: flex;
      justify-content: space-between;
      h5 {
        font-size: 17px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        word-break: normal;
        font-weight: normal;
      }
      p {
        display: flex;
        align-items: center;
        i {
          display: inline-block;
          width: 12px;
          height: 8px;
          margin-right: 4px;
          background-size: 166px 97px;
          vertical-align: bottom;
        }
        span {
          font-size: 12px;
          color: #888;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          word-break: normal;
        }
        span:nth-child(2) {
          padding-right: 3px;
        }
        span:nth-child(3) {
          padding-left: 3px;
        }
      }

      .icon {
        height: 100%;
        line-height: 54px;
        vertical-align: center;
        margin-right: 5px;
        .playing {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          margin-top: 11px;
          i {
            width: 2.5px;
            height: 25px;
            background-color: #d43c33;
            background-image: linear-gradient(#b879ef, #e367d8);
            // display: inline-block;
            transform-origin: center bottom;

            animation: playing 0.6s linear -0.2s infinite alternate-reverse;

            &:first-of-type {
              animation-delay: 0s;
            }
            &:nth-child(3) {
              animation-delay: -0.2s;
            }
            &:nth-child(2) {
              animation-delay: -0.4s;
            }
            &:last-of-type {
              animation-delay: -0.6s;
            }
          }
          &.paused {
            i {
              animation-play-state: paused;
            }
          }
        }

        span {
          display: inline-block;
          width: 22px;
          height: 22px;

          background-position: -24px 0;
          // animation: run 6s linear 0s infinite;
        }
      }
    }
  }
}
@keyframes playing {
  from {
    // height: 50px;
    transform: scaleY(1);
  }
  to {
    // height: 10px;
    transform: scaleY(0.2);
  }
}
</style>