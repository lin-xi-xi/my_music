<template>
  <div>
    <Hotlogo></Hotlogo>
    <hotSongItem :hotSong="hotSong"></hotSongItem>
  </div>
</template>

<script>
import Hotlogo from "../components/Hotlogo";
import hotSongItem from "../components/hotSongItem";
export default {
  components: {
    Hotlogo,
    hotSongItem,
  },
  data() {
    return {
      hotSong: "",
      arr: [],
    };
  },
  created() {
    this.axios
      .get("http://music.kele8.cn/top/list?idx=1")
      .then((response) => {

        this.hotSong = response.data.playlist.trackIds.splice(0, 20);
        this.hotSong.forEach((element) => {
          this.arr.push(element.id);
        });
        this.hotSong = this.arr.join(",");
        this.axios
          .get(`http://music.kele8.cn/song/detail?ids=${this.hotSong}`)
          .then((response) => {
            console.log(response.data.songs);
            this.hotSong=response.data.songs
            
          });
      })
      
  },
};
</script>

<style>
</style>