<template>
  <div class="recomment">
    <RecommmentPlayList :currentRecommments="currentRecommments"
      >推荐歌单</RecommmentPlayList
    >
    <RecommmentNewMusic
      @translate-music="$emit('translate-music', $event)"
      :newSong="newSong"
      :paused="paused"
       :currentMusic="currentMusic"
      :currentIndex="currentIndex"
      >最新音乐</RecommmentNewMusic
    >
  </div>
</template>
<script>
import RecommmentPlayList from "./RecommmentPlayList";
import RecommmentNewMusic from "./RecommmentNewMusic";
export default {
  props:['paused',"currentMusic","currentIndex"],
  components: {
    RecommmentPlayList,
    RecommmentNewMusic,
    
  },
  data() {
    return {
      recommments: [],
      newSong: [],
    };
  },
  methods: {
      translatemusic:function(){
          console.log("chu")
      }
  },
  computed: {
    currentRecommments: function () {
      return this.recommments.slice(0, 6);
    },
  },
  created() {
    this.axios.get("http://music.kele8.cn/personalized").then((response) => {
      console.log(response.data.result);
      this.recommments = response.data.result;
    }),
      this.axios
        .get("http://music.kele8.cn/personalized/newsong")
        .then((response) => {
          console.log(response.data.result);
          this.newSong = response.data.result;
        });
  },
};
</script>

<style>
</style>
