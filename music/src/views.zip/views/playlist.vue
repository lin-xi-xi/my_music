<template>
  <div class="musicPlaylist">
    playlist

    <topNav :creator="creator"></topNav>
    <hotSongItem :hotSong="songitem"></hotSongItem>
  </div>
  <!-- api
   -->
  <!-- http://music.kele8.cn/playlist/detail?id=2819914042 -->
</template>

<script>
import topNav from "../components/musicListNav";
import hotSongItem from '../components/hotSongItem'
export default {
  components: { topNav,hotSongItem },
  data() {
    return {
      creator: "",
      songitem: "",
      arr: [],
    };
  },
  watch:{
    "$route.query.id":function(){
      console.log(this.$route.query)
    }
  },
  created() {

    this.axios
      .get(`http://music.kele8.cn/playlist/detail?id=${this.$route.query.id}`)
      .then((response) => {
        console.log(response.data);
        this.creator = response.data.playlist;
        this.songitem = response.data.playlist.trackIds.splice(0, 20);
        this.songitem.forEach((element) => {
          this.arr.push(element.id);
        });
        this.songitem = this.arr.join(",");
        this.axios
          .get(`http://music.kele8.cn/song/detail?ids=${this.songitem}`)
          .then((response) => {
            console.log(response.data.songs);
            this.songitem = response.data.songs;
          });
      });
  },
};
</script>

<style>
</style>