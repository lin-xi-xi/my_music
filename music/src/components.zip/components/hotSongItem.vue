<template>
  <div>
    <div class="songItem" v-if="hotSong">
      <ul v-for="(item, index) in hotSong" :key="index">
        <span v-if="index < 10">0{{ index }}</span>
        <span v-else>{{ index }}</span>
        <li class="song-item">
          <div>
            <h5>{{ hotSong[index].name }}</h5>
            <p>
              <i :style="imgurl"></i>
              <span v-for="(artist, index2) in hotSong[index].ar" :key="index2">
                <template v-if="index2"> / </template>{{ artist.name }} </span
              ><span>- {{ hotSong[index].al.name }}</span>
            </p>
          </div>
          <div class="icon">
            <span
              v-if="changePaused && hotSong[index].id == changePaused.id"
              class="playing"
              :class="{ paused: changePaused && changePaused.paused == '暂停' }"
            >
              <i></i>
              <i></i>
              <i></i>
              <i></i>
            </span>
            <span :style="imgurl2" v-else></span>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  props: ["hotSong"],
  data() {
    return {
      changePaused: null,
      imgurl: {
        background:
          "url(" + require("../assets/images/index_icon.png") + ")no-repeat",
        backgroundSize: "166px 97px",
      },
      imgurl2: {
        background:
          "url(" +
          require("../assets/images/index_icon.png") +
          ")no-repeat -24px 0",
        backgroundSize: "166px 97px",
      },
    };
  },
  
};
</script>

<style>
</style>